#ifndef __BITMAPS_H
#define __BITMAPS_H

void saveBitmap(unsigned char * bytes, int w, int h, char * fileName);

#endif
